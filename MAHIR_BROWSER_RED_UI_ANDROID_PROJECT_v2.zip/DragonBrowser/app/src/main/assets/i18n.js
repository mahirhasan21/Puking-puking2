/* Tiny i18n + theme bootstrap shared by home.html and panel.html.
   Language / theme come from the URL (?l=bn&t=dark) or, on the home page, from MahirHome.prefs(). */
(function () {
  var D = {
    en: {
      // common
      no: 'No', ok: 'OK', cancel: 'Cancel', search: 'Search', open: 'Open', del: 'Delete',
      justNow: 'just now', minAgo: ' min ago', hAgo: ' h ago', dAgo: ' d ago',
      // menu
      refresh: 'Refresh', bookmark: 'Bookmark', share: 'Share', copyLink: 'Copy link',
      messenger: 'Messenger', quickOpen: 'Quick Open', newTab: 'New Tab', newIncog: 'New Incognito Tab',
      bookmarks: 'Bookmarks', history: 'History', downloads: 'Downloads', desktop: 'Desktop Mode',
      extensions: 'Extensions', settings: 'Settings', help: 'Help & Feedback', about: 'About MAHIR Browser',
      exit: 'Exit', findPage: 'Find in page', print: 'Print / Save PDF', darkTheme: 'Dark theme',
      language: 'Language', premium: 'Premium User',
      // downloads
      all: 'All', video: 'Video', audio: 'Audio', other: 'Other', noDl: 'No downloads yet',
      noDlHint: 'Files you download will appear here', openFolder: 'Open Downloads folder',
      clearAll: 'Clear All', dlFailed: 'Failed', dlPaused: 'Paused', dlRunning: 'Downloading…',
      dlSaved: 'In Downloads', clearDlConfirm: 'All downloads will be removed together with their files. Continue?',
      // bookmarks / history
      noBm: 'No bookmarks yet', noBmHint: 'Open a page and tap "Add Bookmark"', addBm: 'Add Bookmark',
      bmAdded: 'Bookmark added', bmDup: 'Already bookmarked', openPageFirst: 'Open a page first',
      today: 'Today', yest: 'Yesterday', week: '7 Days', noHist: 'No history for this period',
      clearHist: 'Clear History', histCleared: 'History cleared', clearHistConfirm: 'All history will be deleted. Continue?',
      // extensions
      getMore: 'Get more extensions', getMoreSub: 'Add extensions from a ZIP file.', installed: 'Installed Extensions',
      noExt: 'No extensions', noExtHint: 'Tap + above and pick a ZIP file', addZip: 'Add ZIP Extension',
      openPanel: 'Open panel', remove: 'Remove', on: 'Enabled', off: 'Disabled', rmConfirm: 'Remove this extension?',
      // settings
      appearance: 'Appearance', theme: 'Theme', themeSystem: 'System', themeLight: 'Light', themeDark: 'Dark',
      textSize: 'Text size', webDark: 'Dark mode for websites', webDarkSub: 'Darkens web pages in dark theme',
      searchEngine: 'Search engine', privacy: 'Privacy & security', adblock: 'Ad Blocker',
      adblockSub: 'Blocks ads and trackers', saveHist: 'Save browsing history', browserSec: 'Browser',
      defaultBrowser: 'Make default browser', defaultBrowserSub: 'Open links with MAHIR Browser',
      clearData: 'Clear browsing data', clearDataSub: 'History, cache, cookies', clearBtn: 'Clear',
      cHist: 'Browsing history', cCache: 'Cached files', cCookies: 'Cookies & site data', cDl: 'Download list (and files)',
      cleared: 'Cleared', pickOne: 'Select at least one', langSystem: 'System default', chooseLang: 'Choose language',
      chooseTheme: 'Choose theme', chooseEngine: 'Choose search engine', chooseSize: 'Choose text size',
      // incognito
      incog: 'Incognito', incogTitle: 'Incognito Mode', incogSub: "Your browsing activity<br>won't be saved.",
      noHistory: 'No history', noCookies: 'No cookies', noSiteData: 'No site data', startIncog: 'Start Incognito',
      // tabs
      tabsN: 'Tabs', newTabTitle: 'New tab', closeAll: 'Close all', closeAllConfirm: 'Close all tabs?',
      // help / about
      helpLines: ['• Tap the Messenger button at the top to open Messenger.', '• Menu > Extensions: add a ZIP extension.',
        '• Incognito tabs do not save history, cache or cookies.', '• Desktop Mode opens sites in their computer version.',
        '• Menu > Theme / Language lets you switch light-dark and English-বাংলা.', '• Tap a Bookmark or History entry to open it.',
        '• Long-press a link or image on a page for more options.'],
      tagline: 'Fast • Secure • Powerful', surf: 'Surf Smartly...', version: 'Version', loading: 'Loading...',
      // home
      welcome: 'Welcome to', quickTools: 'Quick Tools', seeAll: 'See All', more: 'More'
    },
    bn: {
      no: 'না', ok: 'ঠিক আছে', cancel: 'বাতিল', search: 'খুঁজুন', open: 'খুলুন', del: 'মুছুন',
      justNow: 'এইমাত্র', minAgo: ' মিনিট আগে', hAgo: ' ঘণ্টা আগে', dAgo: ' দিন আগে',
      refresh: 'রিফ্রেশ', bookmark: 'বুকমার্ক', share: 'শেয়ার', copyLink: 'লিংক কপি',
      messenger: 'মেসেঞ্জার', quickOpen: 'দ্রুত খুলুন', newTab: 'নতুন ট্যাব', newIncog: 'নতুন ইনকগনিটো ট্যাব',
      bookmarks: 'বুকমার্ক', history: 'হিস্ট্রি', downloads: 'ডাউনলোড', desktop: 'ডেস্কটপ মোড',
      extensions: 'এক্সটেনশন', settings: 'সেটিংস', help: 'সাহায্য ও মতামত', about: 'MAHIR ব্রাউজার সম্পর্কে',
      exit: 'বের হন', findPage: 'পেজে খুঁজুন', print: 'প্রিন্ট / PDF সেভ', darkTheme: 'ডার্ক থিম',
      language: 'ভাষা', premium: 'প্রিমিয়াম ইউজার',
      all: 'সব', video: 'ভিডিও', audio: 'অডিও', other: 'অন্যান্য', noDl: 'কোনো ডাউনলোড নেই',
      noDlHint: 'ডাউনলোড করা ফাইল এখানে দেখা যাবে', openFolder: 'ডাউনলোড ফোল্ডার খুলুন',
      clearAll: 'সব মুছুন', dlFailed: 'ব্যর্থ হয়েছে', dlPaused: 'থেমে আছে', dlRunning: 'ডাউনলোড হচ্ছে…',
      dlSaved: 'ডাউনলোডে আছে', clearDlConfirm: 'সব ডাউনলোড ফাইলসহ মুছে যাবে। ঠিক আছে?',
      noBm: 'এখনো কোনো বুকমার্ক নেই', noBmHint: 'কোনো পেজ খুলে "বুকমার্ক যোগ" চাপুন', addBm: 'বুকমার্ক যোগ করুন',
      bmAdded: 'বুকমার্ক যোগ হয়েছে', bmDup: 'আগেই বুকমার্ক করা আছে', openPageFirst: 'আগে একটি পেজ খুলুন',
      today: 'আজ', yest: 'গতকাল', week: '৭ দিন', noHist: 'এই সময়ের কোনো হিস্ট্রি নেই',
      clearHist: 'হিস্ট্রি মুছুন', histCleared: 'হিস্ট্রি মুছে গেছে', clearHistConfirm: 'সব হিস্ট্রি মুছে যাবে। ঠিক আছে?',
      getMore: 'আরও এক্সটেনশন', getMoreSub: 'ZIP ফাইল থেকে এক্সটেনশন যোগ করুন।', installed: 'ইনস্টল করা এক্সটেনশন',
      noExt: 'কোনো এক্সটেনশন নেই', noExtHint: 'উপরের + বাটনে চেপে ZIP ফাইল বেছে নিন', addZip: 'ZIP এক্সটেনশন যোগ করুন',
      openPanel: 'প্যানেল খুলুন', remove: 'মুছুন', on: 'চালু আছে', off: 'বন্ধ', rmConfirm: 'এই এক্সটেনশন মুছে ফেলবেন?',
      appearance: 'চেহারা', theme: 'থিম', themeSystem: 'সিস্টেম', themeLight: 'সাদা (লাইট)', themeDark: 'ডার্ক',
      textSize: 'লেখার আকার', webDark: 'ওয়েবসাইটে ডার্ক মোড', webDarkSub: 'ডার্ক থিমে ওয়েব পেজও কালো হবে',
      searchEngine: 'সার্চ ইঞ্জিন', privacy: 'প্রাইভেসি ও নিরাপত্তা', adblock: 'অ্যাড ব্লকার',
      adblockSub: 'বিজ্ঞাপন ও ট্র্যাকার আটকায়', saveHist: 'ব্রাউজিং হিস্ট্রি সেভ করুন', browserSec: 'ব্রাউজার',
      defaultBrowser: 'ডিফল্ট ব্রাউজার করুন', defaultBrowserSub: 'লিংক MAHIR ব্রাউজারে খুলবে',
      clearData: 'ব্রাউজিং ডেটা মুছুন', clearDataSub: 'হিস্ট্রি, ক্যাশ, কুকি', clearBtn: 'মুছুন',
      cHist: 'ব্রাউজিং হিস্ট্রি', cCache: 'ক্যাশ ফাইল', cCookies: 'কুকি ও সাইট ডেটা', cDl: 'ডাউনলোড তালিকা (ফাইলসহ)',
      cleared: 'মুছে ফেলা হয়েছে', pickOne: 'অন্তত একটি বেছে নিন', langSystem: 'সিস্টেম ডিফল্ট', chooseLang: 'ভাষা বেছে নিন',
      chooseTheme: 'থিম বেছে নিন', chooseEngine: 'সার্চ ইঞ্জিন বেছে নিন', chooseSize: 'লেখার আকার বেছে নিন',
      incog: 'ইনকগনিটো', incogTitle: 'ইনকগনিটো মোড', incogSub: 'আপনার ব্রাউজিং<br>সেভ করা হবে না।',
      noHistory: 'হিস্ট্রি নয়', noCookies: 'কুকি নয়', noSiteData: 'সাইট ডেটা নয়', startIncog: 'ইনকগনিটো শুরু করুন',
      tabsN: 'ট্যাব', newTabTitle: 'নতুন ট্যাব', closeAll: 'সব বন্ধ করুন', closeAllConfirm: 'সব ট্যাব বন্ধ করবেন?',
      helpLines: ['• উপরের মেসেঞ্জার বাটনে চাপলে মেসেঞ্জার খুলবে।', '• মেনু > এক্সটেনশন থেকে ZIP ফাইল যোগ করুন।',
        '• ইনকগনিটো ট্যাবে হিস্ট্রি, ক্যাশ ও কুকি সেভ হয় না।', '• ডেস্কটপ মোড চালু করলে সাইট কম্পিউটার ভার্সনে খুলবে।',
        '• মেনু > থিম / ভাষা থেকে সাদা-কালো থিম ও English-বাংলা বদলান।', '• বুকমার্ক/হিস্ট্রিতে ট্যাপ করলে পেজ খুলবে।',
        '• কোনো লিংক বা ছবিতে চেপে ধরলে আরও অপশন আসবে।'],
      tagline: 'দ্রুত • নিরাপদ • শক্তিশালী', surf: 'Surf Smartly...', version: 'ভার্সন', loading: 'লোড হচ্ছে...',
      welcome: 'স্বাগতম', quickTools: 'কুইক টুলস', seeAll: 'সব দেখুন', more: 'আরও'
    }
  };

  function q(n) { try { return new URLSearchParams(location.search).get(n); } catch (e) { return null; } }
  var P = {};
  var l = q('l'), th = q('t');
  if (!l || !th) {
    try {
      if (window.MahirHome && window.MahirHome.prefs) P = JSON.parse(window.MahirHome.prefs()) || {};
    } catch (e) { P = {}; }
  }
  window.LANG = (l || P.lang) === 'bn' ? 'bn' : 'en';
  window.THEME = (th || P.theme) === 'light' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', window.THEME);
  document.documentElement.lang = window.LANG;
  window.t = function (k) {
    var v = D[window.LANG][k];
    if (v === undefined) v = D.en[k];
    return v === undefined ? k : v;
  };
  window.setLook = function (lang, theme) {
    if (lang) { window.LANG = lang === 'bn' ? 'bn' : 'en'; document.documentElement.lang = window.LANG; }
    if (theme) { window.THEME = theme === 'light' ? 'light' : 'dark'; document.documentElement.setAttribute('data-theme', window.THEME); }
  };
})();
